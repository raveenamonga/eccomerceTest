import React from 'react';
import { StyleSheet, Text,View, TouchableOpacity, Image, SafeAreaView, FlatList, StatusBar } from 'react-native';
import { DrawerActions } from 'react-navigation';
import axios from 'axios';

import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp
} from 'react-native-responsive-screen';
import Activity from '../../components/Activity/Activity';


type Props = {
  navigate: PropTypes.func.isRequired
};
class Home extends React.Component {

   state = {
     dataSource: [],
     dataSource2: [],
     selectedCategory: 2,
     responseData: '',
     gettingData: false
   };


  componentDidMount()
  {
    //  this.setState({gettingData: true});
    //   this.getData();
    this.callProductTypeAPI();
    this.callDataAPI();
  }




         callProductTypeAPI() {

           this.props.getProductType()
             .then(() => this.afterProductTypeAPI())
           .catch(e => this.showAlert(e.message, 300));

         }

         afterProductTypeAPI() {
           console.log("isBusy value --- ",this.props.isBusyProductType);
          console.log("response value --- ",this.props.responseProductType);

          var categories = this.props.responseProductType.data;

            this.setState({dataSource: categories});
         }






       callDataAPI() {

         this.props.getAccessriesData('All')
           .then(() => this.afterGetDataAPI())
         .catch(e => this.showAlert(e.message, 300));

       }

       afterGetDataAPI() {
         console.log("isBusy value --- ",this.props.isBusy);
        console.log("response value --- ",this.props.response);

        var data = this.props.response.response.data;
        this.setState({dataSource2: data});



       }









    parseData(){
      if(this.state.responseData!= ''){
        var accessories = this.state.responseData.data.accessories;
        console.log('categories----',accessories);
        this.setState({dataSource: accessories});

            this.seleectCategory(accessories[0]);

      }
    }



   getData(){
     var that =this;
     // Make a request for a user with a given ID
axios.get('http://salescrm.neuronimbus.in/demo/api/getaccessories?customer_id=1')
  .then(function (response) {
     that.setState({responseData: response});
     that.setState({gettingData: false});

     that.parseData();
  })
  .catch(function (error) {
    that.setState({gettingData: false});

  });


   }
  seleectCategory(category){

    this.props.getAccessriesData(category)
      .then(() => this.afterGetDataAPI())
    .catch(e => this.showAlert(e.message, 300));


    // var product_data = category.product_data;
    //   this.setState({dataSource2: product_data});
  }


  openDrawerClick() {
     this.props.navigation.dispatch(DrawerActions.openDrawer());
  }
  goBack(){
    this.props.navigation.goBack();
  }

  openDetail(item){
    this.props.navigation.navigate('Detail',{selectedItem : item});
  }
  goToCart(){
      this.props.navigation.navigate('MyCart');
  }

        showAlert(message, duration) {
          clearTimeout(this.timer);
          this.timer = setTimeout(() => {
            alert(message);
          }, duration);
        }


  render() {

    return (

           <View style={styles.container}>
           <StatusBar backgroundColor="#9979f2" barStyle="light-content" />


           <SafeAreaView style={{flex:1}}>


           <View style={{width: '100%', backgroundColor: 'transparent',  height: wp('50.33%')}}>
           <Image resizeMode="cover" style = {{width: '100%', height:wp('71.33%'),marginTop:-wp('21.33%'), position: 'absolute'}} source = {require('../../../assets/bg1.png')}/>


           <View style={styles.header}>
           <View style={{flex:1, backgroundColor:'transparent', justifyContent: 'center', alignItems: 'center'}}>
            <Text style={styles.txtTitle}> PRODUCT ACCESSORIES </Text>
            <Text style={styles.txtTitleDesc}> that fits your products </Text>
            </View>
            <TouchableOpacity onPress={()=>this.openDrawerClick()} style={styles.backTouchable}>
            <Image resizeMode="contain" style = {styles.backIcon} source = {require('../../../assets/menuWhite.png')}/>
            </TouchableOpacity>
           </View>


                      <View style={[styles.header, {paddingHorizontal: wp('2.6%')}]}>
                      <FlatList
                        data={this.state.dataSource}
                        horizontal= {true}
                        renderItem={({item}) =>
                        <TouchableOpacity onPress={()=>this.seleectCategory(item.product_type_id)} style={{width: wp('21.33%'), alignItems:'center', justifyContent: 'center', height: 100,marginHorizontal:5, backgroundColor: 'transparent'}}>

                           <View style={{width: '100%', height:'100%', alignItems:'center', justifyContent: 'center'}}>
                        <Image resizeMode="contain" style = {{width: '80%', height: '40%'}} source = {{uri: item.product_type_image}} />
                        <Text style={{textAlign: 'center', marginTop: 5, height: wp('16%'), color: 'white', fontSize: 12}}>{item.product_type_name}</Text>
                        </View>
                       </TouchableOpacity>
                       }
                      />
                      </View>



           </View>


           <View style={{width: 'auto', marginTop:0, marginHorizontal:wp('2.6%'), height: wp('10.66%'), justifyContent:'space-between', flexDirection: 'row', alignItems:'center', backgroundColor:'transparent'}}>

           <Text style={{textAlign: 'center', fontFamily: "Rubik-Regular", color: 'black', fontSize: wp('4%')}}>Popular</Text>

              <Image resizeMode="contain" style = {{width: wp('5.33%'), height: wp('5.33%')}} source = {require('../../../assets/search.png')} />

           </View>



           <View style={{flex:1, marginHorizontal:5, backgroundColor:'#edf4f6'}}>

<FlatList
data={this.state.dataSource2}
style={{width: '100%', height: '100%', backgroundColor: 'transparent',marginTop:10}}
renderItem={({ item }) => (
  <TouchableOpacity onPress={()=> this.openDetail(item)} style={{ width:'45%', height:wp('53.33%'),alignItems: 'center', backgroundColor:'white', flexDirection: 'column', margin: 4 , marginLeft:wp('2.6%') }}>
  <Image resizeMode='contain'
   style={{width: '40%', height: '40%', marginVertical: 10, marginLeft:15,}}
        source =  {{uri: item.images[0]}}
      />
      <Text numberOfLines={2}  ellipsizeMode="middle" style={{marginTop: 5,marginLeft:wp('3.2%'),height: wp('12%'), marginRight:wp('3.2%'), width: 'auto', fontFamily: "Rubik-Regular", color: 'black', fontSize: 15}}>{item.accessories_name}</Text>
      <Text style={{ marginTop: 5, marginLeft:wp('2.6%'), fontFamily: "Rubik-Regular", width: '100%', color: 'black', fontSize: wp('4%')}}>RS. {item.price}</Text>
      <Text style={{ marginTop: 5,marginLeft: wp('2.6%'), width:'100%', fontFamily: "Rubik-Bold", color: '#8589ef', fontSize: wp('3.46%')}}>ADD TO CART</Text>
  </TouchableOpacity>
)}
//Setting the number of column
numColumns={2}
keyExtractor={(item, index) => index}
/>
           </View>

           <View style={{width: 'auto', marginHorizontal:wp('2.6%'), flexDirection:'row', height: 50, justifyContent:'space-between', backgroundColor:'white'}}>

           <View style={{width: 'auto',alignItems:'center', flexDirection:'row', height: '100%',  backgroundColor:'transparent'}}>

           <Image resizeMode="contain" style = {{width:wp('6.66%'), height:wp('6.66%')}} source = {require('../../../assets/cartIcon.png')}/>
            <Text style={{textAlign: 'center',marginLeft:wp('2.6%'), fontFamily: "Rubik-Bold",  marginTop: 5, color: 'black', fontSize: wp('4%')}}>0 items </Text>
             <Text style={{textAlign: 'center', fontFamily: "Rubik-Regular", marginTop: 5, color: 'black', fontSize: wp('4%')}}> in your cart</Text>

           </View>




           <TouchableOpacity onPress={()=>this.goToCart()} style={{width: 'auto',alignItems:'center', flexDirection:'row', height: '100%',  backgroundColor:'transparent'}}>


             <Text style={{textAlign: 'center', fontFamily: "Rubik-Regular", color: 'black', fontSize: wp('4%')}}>Go to cart</Text>
             <Image resizeMode="contain" style = {{width:wp('8%'), height:wp('8%'),marginLeft:wp('4%')}} source = {require('../../../assets/go.png')}/>


           </TouchableOpacity>








           </View>





             </SafeAreaView>
             {this.state.gettingData ? <Activity /> : null }
           </View>




    );
  }
}



 const styles = StyleSheet.create({
   container: {
     flex:1,
     backgroundColor: '#edf4f6'
   },
   header: {
     width: '100%',
     height: wp('18.66%'),
     backgroundColor: 'transparent',
     justifyContent:'center',
     alignItems:'center'
   },
   innerView: {
    flex: 1,
     backgroundColor: '#f2f2f2',
     position :'relative',
     alignItems: 'center'
   },



   backTouchable:{
     position: 'absolute',
     width:wp('8.8%'),
     height: wp('10.66%'),
     bottom: wp('2.6%'),
     left: 0
    },
    backIcon: {

     width:wp('5.86%'),
      height: wp('5.86%'),
      marginTop: wp('4%'),
      backgroundColor: 'transparent',
      },
      backTouchable: {

        position: 'absolute',
       width:wp('5.86%'),
        height: '100%',
        top: 0,
        left: wp('4%'),
        backgroundColor: 'transparent',
        },
      txtTitle:{
        color: 'white',
        fontSize: wp('5.33%'),
        fontFamily: "Rubik-Bold"
      },
      txtTitleDesc:{
        color: 'white',
        fontSize: wp('4%'),
        fontFamily: "Rubik-Regular"
      }



 })


export default Home;
