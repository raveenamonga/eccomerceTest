import { NavigationActions } from 'react-navigation';
import MyCart from './MyCart';

export default MyCart;
