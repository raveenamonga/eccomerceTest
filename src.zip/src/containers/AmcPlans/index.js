
import { NavigationActions } from 'react-navigation';
import AmcPlans from './AmcPlans';

export default AmcPlans;
