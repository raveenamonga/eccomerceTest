import { NavigationActions } from 'react-navigation';
import AllEwcPlans from './AllEwcPlans';

export default AllEwcPlans;
