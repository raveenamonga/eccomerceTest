
import { NavigationActions } from 'react-navigation';
import Coupons from './Coupons';

export default Coupons;
