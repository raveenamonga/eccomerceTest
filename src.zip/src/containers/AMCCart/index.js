import { NavigationActions } from 'react-navigation';
import AMCCart from './AMCCart';

export default AMCCart;
