
import { NavigationActions } from 'react-navigation';
import ReferalCode from './ReferalCode';

export default ReferalCode;
