import React from 'react';
import { StyleSheet, Text,View, TouchableOpacity, Image,ScrollView, SafeAreaView, FlatList } from 'react-native';
import { DrawerActions } from 'react-navigation';
import axios from 'axios';

import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp
} from 'react-native-responsive-screen';
import Activity from '../../components/Activity/Activity';







type Props = {
  navigate: PropTypes.func.isRequired
};
export default class Detail extends React.Component {

   state = {
       highlights: [],
       selectedItem: this.props.navigation.getParam('selectedItem', '')
   };


  componentDidMount()
  {
    // var selectedItemValue = this.props.navigation.getParam('selectedItem', '');
    // this.setState({
    //   selectedItem: selectedItemValue
    // });


     this.callGetDetailAPI();

     var sampleArray = [ this.state.selectedItem.highlight ];
     this.setState({
       highlights: sampleArray
     });
  }


  callGetDetailAPI() {

    this.props.getDetail(this.state.selectedItem.id)
      .then(() => this.afterGetDetailAPI())
    .catch(e => this.showAlert(e.message, 300));

  }

  afterGetDetailAPI() {
    console.log("isBusy value --- ",this.props.isBusyGetDetail);
   console.log("response value --- ",this.props.responseGetDetail);

  }





           callAddToCartAPI() {

             this.props.addCartApi(this.state.selectedItem)
               .then(() => this.afterAddCartAPI())
             .catch(e => this.showAlert(e.message, 300));

           }

           afterAddCartAPI() {
             console.log("isBusy value --- ",this.props.isBusy);
            console.log("response value --- ",this.props.response);
              this.callGetCartAPI();
           }



                      callGetCartAPI() {

                        this.props.getCartApi()
                          .then(() => this.afterGetCartAPI())
                        .catch(e => this.showAlert(e.message, 300));

                      }

                      afterGetCartAPI() {
                        console.log("isBusy value --- ",this.props.isBusyGetCart);
                       console.log("response value --- ",this.props.responseGetCart);
                       this.props.navigation.navigate('MyCart');

                      }



           showAlert(message, duration) {
             clearTimeout(this.timer);
             this.timer = setTimeout(() => {
               alert(message);
             }, duration);
           }


  openDrawerClick() {
     this.props.navigation.dispatch(DrawerActions.openDrawer());
  }
  goBack(){
    this.props.navigation.goBack();
  }
  goToCart(){
    this.callAddToCartAPI();
  //  this.props.navigation.navigate('MyCart');
  }
  buyNow(){
    this.props.navigation.navigate('ReviewOrder');
  }





        showAlert(message, duration) {
          clearTimeout(this.timer);
          this.timer = setTimeout(() => {
            alert(message);
          }, duration);
        }


  render() {
        const highlights = this.state.highlights.map((data) => {
      return (
        <View style= {{width:'auto', flexDirection: 'row', marginVertical: 2, height: 'auto', marginHorizontal: wp('5.33%'), backgroundColor: 'transparent'}} >

  <Image resizeMode="cover" style = {{width: wp('2.5%'), marginTop: 5, height:wp('2.5%') }} source = {require('../../../assets/colons.png')}/>

        <Text style={{
          color: '#000000',
          fontSize: wp('4%'),
          marginLeft: wp('2.6%'),
          fontFamily: "Rubik-Light"
        }} >{data}</Text></View>
      )
    });
    return (

           <View style={styles.container}>


          <SafeAreaView style={{flex:1}}>


           <View style={styles.header}>
              <Image resizeMode="cover" style = {{width: '100%', height:'100%', position:'absolute'}} source = {require('../../../assets/header.png')}/>
              <View style={{ width:'100%', height: 40, marginTop: 50,  backgroundColor:'transparent', justifyContent: 'center', alignItems: 'center'}}>
               <Text style={styles.txtTitle}> ACCESSORIES </Text>
               <TouchableOpacity onPress={()=>this.goBack()} style={styles.backTouchable}>
               <Image resizeMode="contain" style = {styles.backIcon} source = {require('../../../assets/backwhite.png')}/>
               </TouchableOpacity>

               <TouchableOpacity onPress={()=>this.goToCart()} style={styles.cartTouchable}>
               <Image resizeMode="contain" style = {styles.backIcon} source = {require('../../../assets/cartWhite.png')}/>
               <View style={{height: 15, justifyContent: 'center', borderRadius: 6 , alignItems: 'center', width: 'auto' , marginHorizontal: 2, position:'absolute', right: 2, top: 4, backgroundColor: 'red'}}>
               <Text style={{color: 'white',  fontSize: 10}} > 0 </Text>
               </View>
               </TouchableOpacity>


               </View>
           </View>

           <View style={{width: '100%', height: 'auto',alignItems: 'center',  marginTop: 0}}>
              <Image resizeMode="cover" style = {{width: '100%', height:wp('10.66%'), position: 'absolute'}} source = {require('../../../assets/curve.png')}/>

              <View style={{width: '85%', height: wp('40%'), justifyContent:'center', alignItems:'center', borderRadius:10, marginTop: -wp('8%'), backgroundColor:'white'}}>
                 <Image resizeMode="contain" style = {{width: '90%', height:'90%'}} source = {{uri: this.state.selectedItem.images[0]}}/>
              </View>


              </View>
              <ScrollView style={{flex:1, backgroundColor: 'transparent', paddingBottom: wp('4%'), marginBottom:0}}>

              <Text style={{
                color: '#3b75c9',
                fontSize: wp('4%'),
                marginTop: wp('5.33%'),
                marginLeft: wp('5.33%'),
                fontFamily: "Rubik-Bold"
              }}> {this.state.selectedItem.product_name} </Text>



              <Text style={{
                color: '#000000',
                fontSize: wp('4.8%'),
                marginTop: 5,
                marginLeft: wp('5.33%'),
                fontFamily: "Rubik-Medium"
              }}> {this.state.selectedItem.accessories_name} </Text>





              <Text style={{
                color: '#000000',
                fontSize: wp('5.9%'),
                marginTop: wp('5.33%'),
                marginLeft: wp('5.33%'),
                fontFamily: "Rubik-Medium"
              }}> Rs. {this.state.selectedItem.price}6 </Text>



              <Text style={{
                color: '#000000',
                fontSize: wp('4%'),
                marginTop: wp('5.33%'),
                marginLeft: wp('5.33%'),
                marginRight:wp('5.33%'),
                fontFamily: "Rubik-Light"
              }}> {this.state.selectedItem.description} </Text>

              <Text style={{
                color: '#000000',
                fontSize: wp('4%'),
                marginTop: wp('5.33%'),
                marginLeft: wp('5.33%'),
                fontFamily: "Rubik-Bold"
              }}> HIGHLIGHTS </Text>


              <View style={{width: '100%', height: 'auto',  marginTop: wp('2.6%')}}>
              {highlights}

               </View>


               <View style={{width: '100%', flexDirection: 'row', justifyContent: 'center', alignItems:'center', height: 'auto',  marginTop: wp('5.33%')}}>

               <TouchableOpacity onPress={()=> this.goToCart()} style={{width: '45%',  height: wp('13.33%'), justifyContent: 'center', alignItems: 'center', marginRight:5, overflow: 'hidden', backgroundColor: 'transparent', borderRadius: 10}}>
               <Image resizeMode="cover" style = {{width: '100%', height: '100%',  position: 'absolute'}} source = {require('../../../assets/button.png')}/>

               <Text style={{
                 color: '#ffffff',
                 fontSize: wp('4%'),

                 fontFamily: "Rubik-Bold"
               }}> ADD TO CART </Text>

                </TouchableOpacity>
                <TouchableOpacity onPress={()=> this.buyNow()} style={{width: '45%', borderColor: '#3b75c9', borderWidth:1, justifyContent: 'center', alignItems: 'center',  height: wp('13.33%'), marginLeft:5,  backgroundColor: 'transparent', borderRadius: 10}}>
                <Text style={{
                  color: '#3b75c9',
                  fontSize: wp('4%'),

                  fontFamily: "Rubik-Bold"
                }}> BUY NOW </Text>

                 </TouchableOpacity>


                </View>
                <View style={{height:20}}>
                </View>

             </ScrollView>

            </SafeAreaView>

           </View>




    );
  }
}



 const styles = StyleSheet.create({
   container: {
     flex:1,
     backgroundColor: '#edf4f6'
   },
   header: {
     width: '100%',
     height: wp('40%'),
     marginTop: -wp('13.33%'),
     backgroundColor: 'transparent'

   },
   innerView: {
    flex: 1,
     backgroundColor: '#f2f2f2',
     position :'relative',
     alignItems: 'center'
   },



    backIcon: {

     width:wp('5.86%'),
      height: wp('5.86%'),

      backgroundColor: 'transparent',
      },
      backTouchable: {

        position: 'absolute',
       width:40,
        height: '100%',
        top: 0,
        left: wp('4%'),
        justifyContent: 'center',
        backgroundColor: 'transparent',
        },
        cartTouchable: {

          position: 'absolute',
         width:wp('10.66%'),
          height: '100%',
          top: 0,
          right: wp('4%'),
          justifyContent: 'center',
          backgroundColor: 'transparent',
          },
      txtTitle:{
        color: 'white',
        fontSize: wp('5.33%'),
        fontFamily: "Rubik-Bold"
      },
      txtTitleDesc:{
        color: 'white',
        fontSize: wp('4.2%'),
        fontFamily: "Rubik-Regular"
      }



 })
