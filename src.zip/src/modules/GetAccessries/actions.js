// @flow
import { Platform } from 'react-native';
import { connect } from 'react-redux';
import axios from 'react-native-axios';
import {
  GETACCESSRIES_REQUEST,
  GETACCESSRIES_SUCCESS,
  GETACCESSRIES_FAILURE
} from './types';
import {  postAPI } from '../../utils/api';
import {  get } from '../../utils/api';
import { getConfiguration } from '../../utils/configuration';



export const getAccessriesData = async (productType) => async (
  dispatch: ReduxDispatch
) => {
  dispatch({
    type: GETACCESSRIES_REQUEST
  });

  try {
    const accessToken = getConfiguration('accessToken');

      var user;
      if(productType == 'All'){
        user = await get('getAllAccessories?access_token='+accessToken);

      }else{
        var url = 'getAllAccessories?access_token='+accessToken + '&product_type_id='+productType;
        user = await get(url);

      }

     return dispatch({
       type: GETACCESSRIES_SUCCESS,
       payload: user
     });
  } catch (e) {
    dispatch({
      type: GETACCESSRIES_FAILURE,
      payload: e && e.message ? e.message : e
    });

    throw e;
  }
};
