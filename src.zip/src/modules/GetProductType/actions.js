// @flow
import { Platform } from 'react-native';
import { connect } from 'react-redux';
import axios from 'react-native-axios';
import {
  PRODUCTYPE_REQUEST,
  PRODUCTYPE_SUCCESS,
  PRODUCTYPE_FAILURE
} from './types';
import {  postAPI } from '../../utils/api';
import {  get } from '../../utils/api';
import { getConfiguration } from '../../utils/configuration';



export const getProductType = async () => async (
  dispatch: ReduxDispatch
) => {
  dispatch({
    type: PRODUCTYPE_REQUEST
  });

  try {
  
    const accessToken = getConfiguration('accessToken');
      const user = await get('getProductType?access_token='+accessToken);

     return dispatch({
       type: PRODUCTYPE_SUCCESS,
       payload: user
     });
  } catch (e) {
    dispatch({
      type: PRODUCTYPE_FAILURE,
      payload: e && e.message ? e.message : e
    });

    throw e;
  }
};
