// @flow
import {
  loginWithPhone
} from './actions';
import reducer from './reducer';

export {
  loginWithPhone
};

export default reducer;
