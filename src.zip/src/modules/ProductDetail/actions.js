// @flow
import { Platform } from 'react-native';
import { connect } from 'react-redux';
import axios from 'react-native-axios';
import {
  DETAIL_REQUEST,
  DETAIL_SUCCESS,
  DETAIL_FAILURE
} from './types';
import {  get } from '../../utils/api';
import { getConfiguration } from '../../utils/configuration';



export const getDetail = async (accessories_id : string) => async (
  dispatch: ReduxDispatch
) => {
  dispatch({
    type: DETAIL_REQUEST
  });

  try {
    const accessToken = getConfiguration('accessToken');
    const customer_id = getConfiguration('customer_id');
   var url = 'accessoriesDetail?access_token='+accessToken+'&accessories_id='+accessories_id;
  const user = await get(url);

     return dispatch({
       type: DETAIL_SUCCESS,
       payload: user
     });
  } catch (e) {
    dispatch({
      type: DETAIL_FAILURE,
      payload: e && e.message ? e.message : e
    });

    throw e;
  }
};
