export const ADDCART_REQUEST = 'AddCart/ADDCART_REQUEST';
export const ADDCART_SUCCESS = 'AddCart/ADDCART_SUCCESS';
export const ADDCART_FAILURE = 'AddCart/ADDCART_FAILURE';



export type State = {
  error: string | null
};
