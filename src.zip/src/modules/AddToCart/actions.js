// @flow
import { Platform } from 'react-native';
import { connect } from 'react-redux';
import axios from 'react-native-axios';
import {
  ADDCART_REQUEST,
  ADDCART_SUCCESS,
  ADDCART_FAILURE
} from './types';
import {  postAPI } from '../../utils/api';
import { getConfiguration } from '../../utils/configuration';



export const addCartApi = async (cart_data: string) => async (
  dispatch: ReduxDispatch
) => {
  dispatch({
    type: ADDCART_REQUEST
  });

  try {
    const accessToken = getConfiguration('accessToken');
    const customer_id = getConfiguration('customer_id');

    console.log(' cart data :- ',cart_data);
    var cartDataStr =  [
{
"item_type": "accessories" ,
"product_item_id": cart_data.id,
"item_name":cart_data.product_name,
"product_group_id": cart_data.product_group_id,
"sub_product_group_id": cart_data.product_group_id,
"model_id":cart_data.model_id,
"serial_no":cart_data.serial_no,
"qty":"1",
"price":cart_data.price,
}
];

    console.log(' cartDataStr data :- ',cartDataStr);
     var str = JSON.stringify(cartDataStr);
     let details = {
       'cart_data': str,
       'customer_id': customer_id

     };

     let formBody = [];
    for (let property in details) {
        let encodedKey = property;   //encodeURIComponent(property);
        let encodedValue =  details[property];   //encodeURIComponent(details[property]);
        formBody.push(encodedKey + "=" + encodedValue);
}
     formBody = formBody.join("&");
     console.log('formBody: ', formBody);
      var url = 'addToCart?access_token='+accessToken
      const user = await postAPI(url,formBody);

     return dispatch({
       type: ADDCART_SUCCESS,
       payload: user
     });
  } catch (e) {
    dispatch({
      type: ADDCART_FAILURE,
      payload: e && e.message ? e.message : e
    });

    throw e;
  }
};
